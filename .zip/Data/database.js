var mongoose = require("mongoose");
var Schema = mongoose.Schema;
mongoose
  .connect(
    "mongodb+srv://Morty:Morty2020@lab-sqsys.mongodb.net/test?retryWrites=true&w=majority",
    {
      useNewUrlParser: true
    }
  )
  .then(function() {
    // Caso Logue Corretamente
    console.log(
      "\x1b[32m[ BANCO DE DADOS ] \x1b[0mBanco de dados foi ligado OK"
    );
  })
  .catch(function() {
    // Caso de ERRO
    console.log(
      "\x1b[31m[ BANCO DE DADOS ] \x1b[0mBanco de dados desligado por erro OK"
    );
  });
var Bot = new Schema({
  idbot: { type: String},
  nome: { type: String},
  texto: { type: String},
  convite: { type: String},
  donoid: {type: String},
  nomedono: {type: String},
  livraria: {type: String},
  servidores: {type: String} ,
  autorizado:{type: Number},
  codigo: {type: String}  ,
  dia: {type: Number}
});
var variavel = new Schema({
  membroid: {type: String},
  level: {type: Number},
  xp: {type: Number},
  rep: {type: Number},
  reputou: {type: Array, default: []},
  cooldown: {type: Number},
  salavip: {type: String}
})
var blo = new Schema({
  ip: {type: String},
  stats: {type: String},
  email: {type: String},
  usuarioid: {type:String}
})
var Bots = mongoose.model("Bots", Bot);
var Usuarios = mongoose.model("Usuarios", variavel);
var sec = mongoose.model("Segurança", blo);
exports.Seguranca = sec;
exports.Membros = Usuarios;
exports.Bots = Bots;

