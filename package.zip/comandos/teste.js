const Discord = require('discord.js')
exports.run = async (client, message, args) => {
    
}
exports.help = {
  name: 'teste',
  uso: "!teste",
  permissao: "Usuario",
  descricao: "Usado para Saber Meus Comandos :]"
}